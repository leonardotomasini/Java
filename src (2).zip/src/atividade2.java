import javax.swing.*;
import java.awt.*;

///também não consegui fazer o botão do form rodar

public class atividade2 {
    private JTextField textField2;
    private JTextField textField1;
    private JTextField textField3;
    private JButton button1;

    public static void main(String[] args) {
        JTextField Cateto1 = new JTextField(10);
        JTextField Cateto2 = new JTextField(10);
        JLabel resultado = new JLabel("Hipotenusa: ");
        JButton calcularButton = new JButton("Calcular");
        calcularButton.addActionListener(e -> {
            try {
                double cateto1 = Double.parseDouble(Cateto1.getText());
                double cateto2 = Double.parseDouble(Cateto2.getText());
                double hipotenusa = Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));
                resultado.setText("Hipotenusa: " + hipotenusa);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Apenas números.");
                Cateto2.setText("");
            }
        });

        JPanel painel = new JPanel(new GridLayout(4, 2, 10, 10));
        painel.add(new JLabel("Cateto 1: "));
        painel.add(Cateto1);
        painel.add(new JLabel("Cateto 2: "));
        painel.add(Cateto2);
        painel.add(calcularButton);
        painel.add(resultado);

        JFrame frame = new JFrame("Calculadora de hipotenusa");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.add(painel, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
