import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class atividade3 extends JFrame {
    private JTextField textField1;
    private JRadioButton verãoRadioButton;
    private JRadioButton outonoRadioButton;
    private JRadioButton primaveraRadioButton;
    private JRadioButton invernoRadioButton;
    private JCheckBox montanhasCheckBox;
    private JCheckBox florestasCheckBox;
    private JCheckBox pãntanosCheckBox;
    private JCheckBox desertoCheckBox;
    private JCheckBox tundrasCheckBox;
    private JCheckBox planicesCheckBox;
    private JCheckBox praiasCheckBox;
    private JCheckBox estepesCheckBox;
    private JButton enviarButton;
    private ButtonGroup grupoEstacao;

    public atividade3() {
        setTitle("Atividade 3");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        textField1 = new JTextField();

        verãoRadioButton = new JRadioButton("Verão");
        outonoRadioButton = new JRadioButton("Outono");
        primaveraRadioButton = new JRadioButton("Primavera");
        invernoRadioButton = new JRadioButton("Inverno");

        verãoRadioButton.setActionCommand("Verão");
        outonoRadioButton.setActionCommand("Outono");
        primaveraRadioButton.setActionCommand("Primavera");
        invernoRadioButton.setActionCommand("Inverno");

        montanhasCheckBox = new JCheckBox("Montanhas");
        florestasCheckBox = new JCheckBox("Florestas");
        pãntanosCheckBox = new JCheckBox("Pântanos");
        desertoCheckBox = new JCheckBox("Deserto");
        tundrasCheckBox = new JCheckBox("Tundras");
        planicesCheckBox = new JCheckBox("Planícies");
        praiasCheckBox = new JCheckBox("Praias");
        estepesCheckBox = new JCheckBox("Estepes");

        enviarButton = new JButton("Enviar");

        grupoEstacao = new ButtonGroup();
        grupoEstacao.add(verãoRadioButton);
        grupoEstacao.add(outonoRadioButton);
        grupoEstacao.add(primaveraRadioButton);
        grupoEstacao.add(invernoRadioButton);

        JPanel nomePanel = new JPanel(new BorderLayout());
        nomePanel.setBorder(BorderFactory.createTitledBorder("Nome"));
        nomePanel.add(textField1, BorderLayout.CENTER);

        JPanel estacaoPanel = new JPanel(new GridLayout(4, 1));
        estacaoPanel.setBorder(BorderFactory.createTitledBorder("Estação Preferida"));
        estacaoPanel.add(verãoRadioButton);
        estacaoPanel.add(outonoRadioButton);
        estacaoPanel.add(primaveraRadioButton);
        estacaoPanel.add(invernoRadioButton);

        JPanel preferenciasPanel = new JPanel(new GridLayout(8, 1));
        preferenciasPanel.setBorder(BorderFactory.createTitledBorder("Preferências"));
        preferenciasPanel.add(montanhasCheckBox);
        preferenciasPanel.add(florestasCheckBox);
        preferenciasPanel.add(pãntanosCheckBox);
        preferenciasPanel.add(desertoCheckBox);
        preferenciasPanel.add(tundrasCheckBox);
        preferenciasPanel.add(planicesCheckBox);
        preferenciasPanel.add(praiasCheckBox);
        preferenciasPanel.add(estepesCheckBox);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(nomePanel, BorderLayout.NORTH);
        mainPanel.add(estacaoPanel, BorderLayout.CENTER);
        mainPanel.add(preferenciasPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
        add(enviarButton, BorderLayout.SOUTH);

        enviarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textField1.getText();
                String estacaoPreferida = grupoEstacao.getSelection().getActionCommand();
                List<String> preferencias = new ArrayList<>();
                if (montanhasCheckBox.isSelected()) preferencias.add(montanhasCheckBox.getText());
                if (florestasCheckBox.isSelected()) preferencias.add(florestasCheckBox.getText());
                if (pãntanosCheckBox.isSelected()) preferencias.add(pãntanosCheckBox.getText());
                if (desertoCheckBox.isSelected()) preferencias.add(desertoCheckBox.getText());
                if (tundrasCheckBox.isSelected()) preferencias.add(tundrasCheckBox.getText());
                if (planicesCheckBox.isSelected()) preferencias.add(planicesCheckBox.getText());
                if (praiasCheckBox.isSelected()) preferencias.add(praiasCheckBox.getText());
                if (estepesCheckBox.isSelected()) preferencias.add(estepesCheckBox.getText());

                String preferenciasStr = String.join(", ", preferencias);
                JOptionPane.showMessageDialog(null, String.format("Nome: %s\nEstação preferida: %s\nPreferências: %s", nome, estacaoPreferida, preferenciasStr));
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new atividade3();
        frame.setVisible(true);
    }
}
