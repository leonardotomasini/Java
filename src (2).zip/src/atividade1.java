import javax.swing.*;
import java.awt.*;

/// tentei fazer de todas maneiras possiveis no form mas não conseguia fazer o botão rodar e não achei na internet como resolver o erro

public class atividade1 {
    private JPanel mainPanel;
    private JTextField textField1;
    private JButton button1;
    private JLabel label1;

    public atividade1() {
        mainPanel = new JPanel(new BorderLayout());
        JPanel centerPanel = new JPanel(new FlowLayout());
        textField1 = new JTextField(20);
        button1 = new JButton("Salva texto");
        centerPanel.add(textField1);
        centerPanel.add(button1);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        label1 = new JLabel("A mensagem aparecerá aqui", SwingConstants.CENTER);
        mainPanel.add(label1, BorderLayout.SOUTH);
        button1.addActionListener(e -> atualizarLabel());
        textField1.addActionListener(e -> atualizarLabel());
    }

    private void atualizarLabel() {
        label1.setText(textField1.getText());
        textField1.setText("");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Atividade 1");
        atividade1 app = new atividade1();
        frame.setContentPane(app.mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        frame.setVisible(true);
    }
}
