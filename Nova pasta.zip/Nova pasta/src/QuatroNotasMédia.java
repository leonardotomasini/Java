import java.util.Scanner;

public class QuatroNotasMédia {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] notas = new double[4];
        double media = 0;
        for (int i = 0; i < 4; i++) {
            System.out.print("Digite a nota " + (i + 1) + ": ");
            notas[i] = scanner.nextDouble();
            if (notas[i] < 0 || notas[i] > 10) {
                System.out.println("As notas devem ser entre 0 e 10.");
                return;
            }
            media += notas[i];
        }
        media /= 4;
        if (media >= 7) {
            System.out.printf("Média: %.2f - Status: Aprovado\n", media);
        } else {
            System.out.printf("Média: %.2f - Aluno de exame.\n", media);
            System.out.print("Digite a nota de exame: ");
            double exame = scanner.nextDouble();
            if (exame < 0 || exame > 10) {
                System.out.println("Nota inválida! As notas devem estar entre 0 e 10.");
                return;
            }
            double novaMedia = (media + exame) / 2;
            if (novaMedia >= 5) {
                System.out.printf("Nova média: %.2f - Status: Aprovado em exame\n", novaMedia);
            } else {
                System.out.printf("Nova média: %.2f - Status: Reprovado\n", novaMedia);
            }
        }
        scanner.close();
    }
}