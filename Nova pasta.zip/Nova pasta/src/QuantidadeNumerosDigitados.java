import javax.swing.JOptionPane;

public class QuantidadeNumerosDigitados {
    public static void main(String[] args) {
        int[] numeros = new int[100];
        int total = 0, contador = 0, numero = -1;

        while (numero != 0 && contador < 100) {
            numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número (0 para finalizar):"));
            if (numero != 0) {
                numeros[contador++] = numero;
                total += numero;
            }
        }
        JOptionPane.showMessageDialog(null, contador > 0
                ? "A média dos números digitados é: " + (double) total / contador : "Nenhum número foi escrito.");
    }
}