import javax.swing.JOptionPane;
import java.util.Arrays;

public class OrdemCrescente {
    public static void main(String[] args) {
        int[] numeros = new int[10];
        for (int i = 0; i < 10; i++) {
            numeros[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o número " + (i + 1) + ":"));
        }
        Arrays.sort(numeros);
        StringBuilder resultado = new StringBuilder("Números em ordem crescente:\n");
        for (int num : numeros) {
            resultado.append(num).append("\n");
        }
        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}