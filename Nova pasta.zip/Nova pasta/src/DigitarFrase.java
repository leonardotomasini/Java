import javax.swing.JOptionPane;

public class DigitarFrase {
    public static void main(String[] args) {
        String frase = JOptionPane.showInputDialog("Digite a frase:");
        String[] palavras = frase.split(" ");

        StringBuilder resultado = new StringBuilder("Palavras separadas:\n");
        for (String palavra : palavras) {
            resultado.append(palavra).append("\n");
        }

        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}