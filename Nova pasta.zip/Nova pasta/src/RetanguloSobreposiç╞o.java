import javax.swing.JOptionPane;

public class RetanguloSobreposição {

    public static void main(String[] args) {
        ClasseRetanguloDois[] retangulos = new ClasseRetanguloDois[3];

        for (int i = 0; i < 3; i++) {
            double x = Double.parseDouble(JOptionPane.showInputDialog("Digite a coordenada x do retângulo " + (i + 1) + ":"));
            double y = Double.parseDouble(JOptionPane.showInputDialog("Digite a coordenada y do retângulo " + (i + 1) + ":"));
            double largura = Double.parseDouble(JOptionPane.showInputDialog("Digite a largura do retângulo " + (i + 1) + ":"));
            double altura = Double.parseDouble(JOptionPane.showInputDialog("Digite a altura do retângulo " + (i + 1) + ":"));

            retangulos[i] = new ClasseRetanguloDois(x, y, largura, altura);
        }

        for (int i = 0; i < 3; i++) {
            for (int j = i + 1; j < 3; j++) {
                retangulos[i].verificarSobreposicao(retangulos[j], i, j);
            }
        }
    }
}