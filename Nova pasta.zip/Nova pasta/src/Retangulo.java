import javax.swing.JOptionPane;

public class Retangulo {
    public static void main(String[] args) {
        ClasseRetangulo[] retangulos = new ClasseRetangulo[5];
        double areaTotal = 0, perimetroTotal = 0;
        for (int i = 0; i < 5; i++) {
            double largura = 0, altura = 0;
            String inputLargura = JOptionPane.showInputDialog(null, "Escreva a largura do retângulo " + (i + 1) + ":");
            if (inputLargura == null) return;
            largura = Double.parseDouble(inputLargura);
            String inputAltura = JOptionPane.showInputDialog(null, "Escreva a altura do retângulo " + (i + 1) + ":");
            if (inputAltura == null) return;
            altura = Double.parseDouble(inputAltura);
            retangulos[i] = new ClasseRetangulo(largura, altura);
            double area = retangulos[i].calcularArea();
            double perimetro = retangulos[i].calcularPerimetro();
            areaTotal += area;
            perimetroTotal += perimetro;
            JOptionPane.showMessageDialog(null, "Retângulo " + (i + 1) + ":\n" +
                    "Área: " + area + "\n" +
                    "Perímetro: " + perimetro);
        }
        JOptionPane.showMessageDialog(null, String.format("Área total de todos os retângulos: %.2f\nPerímetro total: %.2f", areaTotal, perimetroTotal));
    }
}