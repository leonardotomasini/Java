import javax.swing.JOptionPane;
import java.util.Arrays;

public class Mediana {
    public static void main(String[] args) {
        int[] numeros = new int[10];
        for (int i = 0; i < 10; i++) {
            numeros[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o número " + (i + 1) + ":"));
        }
        Arrays.sort(numeros);
        double mediana = (numeros[4] + numeros[5]) / 2.0;
        JOptionPane.showMessageDialog(null, "A mediana dos números é: " + mediana);
    }
}