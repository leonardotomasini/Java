import javax.swing.JOptionPane;
public class ClasseRetanguloDois {
    private double x, y;
    private double largura, altura;
    public ClasseRetanguloDois(double x, double y, double largura, double altura) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
    }
    public void verificarSobreposicao(ClasseRetanguloDois outro, int index1, int index2) {
        if (this.x + this.largura <= outro.x ||
                outro.x + outro.largura <= this.x ||
                this.y + this.altura <= outro.y ||
                outro.y + outro.altura <= this.y)
        {
            return;
        }
        JOptionPane.showMessageDialog(null, "O retângulo " + (index1 + 1) + " sobrepõe o retângulo " + (index2 + 1));
    }
}