import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProjetoViveiro extends JFrame {
    private JPanel panel1;
    private JButton removerPlantasButton;
    private JButton editarInformaçõesButton;
    private JButton adicionarPlantasButton;
    private JButton exibiçãoButton;
    private JPanel JPanelSeleção;
    private JPanel JPanelConfigurações;
    private JPanel JPanelCard;
    private JPanel JPanelAdição;
    private JPanel JPanelRemovação;
    private JPanel JPanelEdição;
    private JPanel JPanelExibição;
    private JButton Adicionar;
    private JButton removerButton;
    private JTextField textField2;
    private JButton editarButton;
    private JButton Exibir;
    private JTextField textField1;
    private JTextField textField3;
    private JRadioButton pteridofitaRadioButton;
    private JRadioButton gminospermaRadioButton;
    private JRadioButton angiospermaRadioButton;
    private JRadioButton briofitaRadioButton;
    private JRadioButton a02MetrosRadioButton;
    private JRadioButton a210MetrosRadioButton;
    private JRadioButton a1030MetrosRadioButton;
    private JRadioButton a3060MetrosRadioButton;
    private JRadioButton muitoRapidaRadioButton;
    private JRadioButton rapidaRadioButton;
    private JRadioButton moderadaRadioButton;
    private JRadioButton lentaRadioButton;
    private JRadioButton a02MetrosRadioButton1;
    private JRadioButton a3060MetrosRadioButton1;
    private JRadioButton a210MetrosRadioButton1;
    private JRadioButton a1030MetrosRadioButton1;
    private JRadioButton briófitaRadioButton;
    private JRadioButton pteridófitaRadioButton;
    private JRadioButton gminospermaRadioButton1;
    private JRadioButton angiospermaRadioButton1;
    private JRadioButton muitoRápidaRadioButton;
    private JRadioButton rápidaRadioButton;
    private JRadioButton moderadaRadioButton1;
    private JRadioButton lentaRadioButton1;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JButton buscarButton;
    private ArrayList<Planta> listaPlantas;

    public ProjetoViveiro() {
        setSize(1000, 500);
        setVisible(true);
        setContentPane(panel1);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Programa Viveiro");
        criarTabela();
        listaPlantas = new ArrayList<>();


        CardLayout layoutManager = (CardLayout) JPanelCard.getLayout();
        JPanelCard.add(JPanelAdição, "JPanelAdição");
        JPanelCard.add(JPanelRemovação, "JPanelRemovação");
        JPanelCard.add(JPanelEdição, "JPanelEdição");
        JPanelCard.add(JPanelExibição, "JPanelExibição");

        adicionarPlantasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                layoutManager.show(JPanelCard, "JPanelAdição");
            }
        });

        removerPlantasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                layoutManager.show(JPanelCard, "JPanelRemovação");
            }
        });

        editarInformaçõesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                layoutManager.show(JPanelCard, "JPanelEdição");
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textField3.getText();
                String tipo = getSelectedTipo();
                String altura = getSelectedAltura();
                String velocidade = getSelectedVelocidade();

                editarPlanta(nome, tipo, altura, velocidade);
                resetarCamposEdicao();
            }

            private String getSelectedTipo() {
                if (briofitaRadioButton.isSelected()) return "Briófita";
                if (pteridófitaRadioButton.isSelected()) return "Pteridófita";
                if (gminospermaRadioButton1.isSelected()) return "Gminosperma";
                if (angiospermaRadioButton1.isSelected()) return "Angiosperma";
                return "";
            }

            private String getSelectedAltura() {
                if (a02MetrosRadioButton1.isSelected()) return "0-2 metros";
                if (a210MetrosRadioButton1.isSelected()) return "2-10 metros";
                if (a1030MetrosRadioButton1.isSelected()) return "10-30 metros";
                if (a3060MetrosRadioButton1.isSelected()) return "30-60 metros";
                return "";
            }

            private String getSelectedVelocidade() {
                if (lentaRadioButton1.isSelected()) return "Lenta";
                if (moderadaRadioButton1.isSelected()) return "Moderada";
                if (rapidaRadioButton.isSelected()) return "Rápida";
                if (muitoRápidaRadioButton.isSelected()) return "Muito Rápida";
                return "";
            }
        });

        exibiçãoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                layoutManager.show(JPanelCard, "JPanelExibição");
            }
        });


        ButtonGroup grupoVelocidade = new ButtonGroup();
        grupoVelocidade.add(lentaRadioButton);
        grupoVelocidade.add(moderadaRadioButton);
        grupoVelocidade.add(rapidaRadioButton);
        grupoVelocidade.add(muitoRapidaRadioButton);

        ButtonGroup grupoAltura = new ButtonGroup();
        grupoAltura.add(a02MetrosRadioButton);
        grupoAltura.add(a210MetrosRadioButton);
        grupoAltura.add(a1030MetrosRadioButton);
        grupoAltura.add(a3060MetrosRadioButton);

        ButtonGroup grupoBotanico = new ButtonGroup();
        grupoBotanico.add(briofitaRadioButton);
        grupoBotanico.add(pteridofitaRadioButton);
        grupoBotanico.add(gminospermaRadioButton);
        grupoBotanico.add(angiospermaRadioButton);

        Adicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!pteridofitaRadioButton.isSelected() && !gminospermaRadioButton.isSelected() &&
                        !angiospermaRadioButton.isSelected() && !briofitaRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Não pode adicionar sem selecionar o grupo botãnico. ");
                    return;
                }
                if (!a02MetrosRadioButton.isSelected() && !a210MetrosRadioButton.isSelected() &&
                        !a1030MetrosRadioButton.isSelected() && !a3060MetrosRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Não pode adicionar sem selecionar a altura.");
                    return;
                }
                if (!lentaRadioButton.isSelected() && !moderadaRadioButton.isSelected() &&
                        !rapidaRadioButton.isSelected() && !muitoRapidaRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Não pode adicionar sem selecionar o crescimento.");
                    return;
                }

                String nome = textField1.getText();

                String tipo = "";
                if (briofitaRadioButton.isSelected()) tipo = "Briófita";
                else if (pteridofitaRadioButton.isSelected()) tipo = "Pteridófita";
                else if (gminospermaRadioButton.isSelected()) tipo = "Gminosperma";
                else if (angiospermaRadioButton.isSelected()) tipo = "Angiosperma";

                String altura = "";
                if (a02MetrosRadioButton.isSelected()) altura = "0-2 metros";
                else if (a210MetrosRadioButton.isSelected()) altura = "2-10 metros";
                else if (a1030MetrosRadioButton.isSelected()) altura = "10-30 metros";
                else if (a3060MetrosRadioButton.isSelected()) altura = "30-60 metros";

                String velocidade = "";
                if (lentaRadioButton.isSelected()) velocidade = "Lenta";
                else if (moderadaRadioButton.isSelected()) velocidade = "Moderada";
                else if (rapidaRadioButton.isSelected()) velocidade = "Rápida";
                else if (muitoRapidaRadioButton.isSelected()) velocidade = "Muito Rápida";

                salvarNoBanco(nome, tipo, altura, velocidade);
            }
        });


        removerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textField2.getText();
                excluirPlanta(nome);
            }
        });

        Exibir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirPlantas();
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textField3.getText();

                String tipo = "";
                if (briófitaRadioButton.isSelected()) tipo = "Briófita";
                else if (pteridófitaRadioButton.isSelected()) tipo = "Pteridófita";
                else if (gminospermaRadioButton1.isSelected()) tipo = "Gminosperma";
                else if (angiospermaRadioButton1.isSelected()) tipo = "Angiosperma";

                String altura = "";
                if (a02MetrosRadioButton1.isSelected()) altura = "0-2 metros";
                else if (a210MetrosRadioButton1.isSelected()) altura = "2-10 metros";
                else if (a1030MetrosRadioButton1.isSelected()) altura = "10-30 metros";
                else if (a3060MetrosRadioButton1.isSelected()) altura = "30-60 metros";

                String velocidade = "";
                if (lentaRadioButton1.isSelected()) velocidade = "Lenta";
                else if (moderadaRadioButton1.isSelected()) velocidade = "Moderada";
                else if (rápidaRadioButton.isSelected()) velocidade = "Rápida";
                else if (muitoRápidaRadioButton.isSelected()) velocidade = "Muito Rápida";

                editarPlanta(nome, tipo, altura, velocidade);
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textField3.getText();
                ArrayList<String> detalhes = buscarPlanta(nome);
                if (!detalhes.isEmpty()) {
                    textField6.setText(detalhes.get(4));
                    textField7.setText(detalhes.get(5));

                    String tipo = detalhes.get(1);
                    if (tipo.equals("Briófita")) briofitaRadioButton.setSelected(true);
                    else if (tipo.equals("Pteridófita")) pteridófitaRadioButton.setSelected(true);
                    else if (tipo.equals("Gminosperma")) gminospermaRadioButton1.setSelected(true);
                    else if (tipo.equals("Angiosperma")) angiospermaRadioButton1.setSelected(true);

                    String altura = detalhes.get(2);
                    if (altura.equals("0-2 metros")) a02MetrosRadioButton1.setSelected(true);
                    else if (altura.equals("2-10 metros")) a210MetrosRadioButton1.setSelected(true);
                    else if (altura.equals("10-30 metros")) a1030MetrosRadioButton1.setSelected(true);
                    else if (altura.equals("30-60 metros")) a3060MetrosRadioButton1.setSelected(true);

                    String velocidade = detalhes.get(3);
                    if (velocidade.equals("Lenta")) lentaRadioButton1.setSelected(true);
                    else if (velocidade.equals("Moderada")) moderadaRadioButton1.setSelected(true);
                    else if (velocidade.equals("Rápida")) rapidaRadioButton.setSelected(true);
                    else if (velocidade.equals("Muito Rápida")) muitoRápidaRadioButton.setSelected(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Planta não encontrada.");
                }
            }
        });
    }

    private ArrayList<String> buscarPlanta(String nome) {
        ArrayList<String> detalhes = new ArrayList<>();
        String query = "SELECT * FROM Plantas WHERE nome = ?";
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/base.db");
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nome);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                detalhes.add(rs.getString("nome"));
                detalhes.add(rs.getString("tipo"));
                detalhes.add(rs.getString("altura"));
                detalhes.add(rs.getString("velocidade"));
                detalhes.add(rs.getString("preco"));
                detalhes.add(rs.getString("informacoes"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return detalhes;
    }

    private void resetarCamposEdicao() {
        textField3.setText("");
        textField6.setText("");
        textField7.setText("");
        briófitaRadioButton.setSelected(false);
        pteridófitaRadioButton.setSelected(false);
        gminospermaRadioButton1.setSelected(false);
        angiospermaRadioButton1.setSelected(false);
        a02MetrosRadioButton1.setSelected(false);
        a210MetrosRadioButton1.setSelected(false);
        a1030MetrosRadioButton1.setSelected(false);
        a3060MetrosRadioButton1.setSelected(false);
        lentaRadioButton1.setSelected(false);
        moderadaRadioButton1.setSelected(false);
        rápidaRadioButton.setSelected(false);
        muitoRápidaRadioButton.setSelected(false);
    }

    private void salvarNoBanco(String nome, String tipo, String altura, String velocidade) {
        String preco = textField4.getText();
        String informacoes = textField5.getText();

        if (nome == null || nome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite um nome para a planta.");
            return;
        }
        if (preco == null || preco.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite o preço da planta.");
            return;
        }
        if (informacoes == null || informacoes.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite as informações pessoais da planta.");
            return;
        }
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/base.db");
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO Plantas (nome, tipo, altura, velocidade, preco, informacoes) VALUES (?, ?, ?, ?, ?, ?)")) {
            preparedStatement.setString(1, nome);
            preparedStatement.setString(2, tipo);
            preparedStatement.setString(3, altura);
            preparedStatement.setString(4, velocidade);
            preparedStatement.setString(5, preco);
            preparedStatement.setString(6, informacoes);
            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(this, "Planta adicionada ao viveiro.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void criarTabela() {
        String sql = "CREATE TABLE IF NOT EXISTS Plantas ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "nome TEXT NOT NULL, "
                + "tipo TEXT, "
                + "altura TEXT, "
                + "velocidade TEXT);";
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/base.db");
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.execute();
            System.out.println("Tabela Plantas criada com sucesso (ou já existe).");
        } catch (SQLException e) {
            System.out.println("Erro ao criar a tabela: " + e.getMessage());
        }
    }

    private void excluirPlanta(String nome) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/base.db");
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "DELETE FROM Plantas WHERE nome = ?")) {
            preparedStatement.setString(1, nome);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Planta removida do viveiro..");
            } else {
                JOptionPane.showMessageDialog(this, "Planta não encontrada.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao remover. " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void editarPlanta(String nome, String tipo, String altura, String velocidade) {
        String preco = textField6.getText();
        String informacoes = textField7.getText();

        if (nome == null || nome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "A planta precisa de um nome.");
            return;
        }
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/base.db");
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "UPDATE Plantas SET tipo = ?, altura = ?, velocidade = ?, preco = ?, informacoes = ? WHERE nome = ?")) {
            preparedStatement.setString(1, tipo);
            preparedStatement.setString(2, altura);
            preparedStatement.setString(3, velocidade);
            preparedStatement.setString(4, preco);
            preparedStatement.setString(5, informacoes);
            preparedStatement.setString(6, nome);
            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Características modificadas.");
            } else {
                JOptionPane.showMessageDialog(this, "Nome errado.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void exibirPlantas() {
        StringBuilder resultado = new StringBuilder();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/base.db");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Plantas");
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String nome = resultSet.getString("nome");
                String tipo = resultSet.getString("tipo");
                String altura = resultSet.getString("altura");
                String velocidade = resultSet.getString("velocidade");
                String preco = resultSet.getString("preco");
                String informacoes = resultSet.getString("informacoes");
                resultado.append("Nome: ").append(nome)
                        .append(", Tipo: ").append(tipo)
                        .append(", Altura: ").append(altura)
                        .append(", Velocidade: ").append(velocidade)
                        .append(", Preço: ").append(preco)
                        .append(", Informações: ").append(informacoes).append("\n");
            }
            if (resultado.length() == 0) {
                resultado.append("Nenhuma planta encontrada.");
            }
        } catch (SQLException e) {
            resultado.append("Erro ao buscar plantas: ").append(e.getMessage());
        }
        JOptionPane.showMessageDialog(this, resultado.toString(), "Plantas do viveiro", JOptionPane.INFORMATION_MESSAGE);
    }


    public static void main(String[] args) {
        new ProjetoViveiro();
    }
}