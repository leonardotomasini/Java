public class Planta {
    private String nome;
    private String tipo;
    private String altura;
    private String velocidade;
    private String preco;
    private String informacoes;

    public Planta(String nome, String tipo, String altura, String velocidade, String preco, String informacoes) {
        this.nome = nome;
        this.tipo = tipo;
        this.altura = altura;
        this.velocidade = velocidade;
        this.preco = preco;
        this.informacoes = informacoes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public String getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(String velocidade) {
        this.velocidade = velocidade;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getInformacoes() {
        return informacoes;
    }

    public void setInformacoes(String informacoes) {
        this.informacoes = informacoes;
    }
}
