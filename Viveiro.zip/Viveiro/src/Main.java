import java.sql.*;
public class Main {
    public static void main(String[] args) {
        String databasePath = "src/base.db";
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + databasePath)) {
            System.out.println("Conexão realizada. ");
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
        new ProjetoViveiro();
    }
}
