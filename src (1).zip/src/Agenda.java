import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Agenda {
    List<Contato> listaDeContatos;

    public Agenda() {
        listaDeContatos = new ArrayList<>();
    }

    public List<Contato> getListaDeContatos() {
        return listaDeContatos;
    }

    public void setListaDeContatos(List<Contato> listaDeContatos) {
        this.listaDeContatos = listaDeContatos;
    }

    public boolean criarContato(String nome, String telefone, String email) {
        Contato c = new Contato(nome);
        c.setEmail(email);
        c.setTelefone(telefone);

        if (listaDeContatos.contains(c)) {
            return false; // Contato já existe
        } else {
            listaDeContatos.add(c);
            return true;
        }
    }

    public Contato buscarPorNome(String nome) {
        for (Contato contatoAtual : listaDeContatos) {
            if (contatoAtual.getNome().equals(nome)) {
                return contatoAtual;
            }
        }
        return null;
    }

    private int buscarIndice(String nome) {
        for (int i = 0; i < listaDeContatos.size(); i++) {
            if (listaDeContatos.get(i).getNome().equals(nome)) {
                return i;
            }
        }
        return -1;
    }

    public boolean excluirContato(String nome) {
        int indice = buscarIndice(nome);
        if (indice != -1) {
            listaDeContatos.remove(indice);
            return true;
        }
        return false;
    }

    public boolean editarContato(String nomeAntigo, Contato novoContato) {
        int indice = buscarIndice(nomeAntigo);
        if (indice != -1) {
            listaDeContatos.set(indice, novoContato);
            return true;
        }
        return false;
    }

    public Contato[] listar() {
        return listaDeContatos.toArray(new Contato[0]);
    }

    public boolean salvar() {
        File file = new File("agenda.txt");
        try (FileWriter fw = new FileWriter(file)) {
            for (Contato contato : listaDeContatos) {
                fw.write(contato.getNome() + " | " + contato.getTelefone() + " | " + contato.getEmail() + "\n");
            }
            return true; //
        } catch (IOException e) {
            System.err.println("Erro ao salvar o arquivo: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

}