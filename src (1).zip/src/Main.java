import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        Agenda agenda = new Agenda();
        String[] opcoes = {"Adicionar", "Buscar por Nome", "Buscar por Índice", "Excluir", "Editar", "Listar", "Sair"};

        while (true) {
            int escolha = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opcoes, opcoes[0]);

            if (escolha == 0) {
                agenda.getListaDeContatos().add(new Contato(
                        JOptionPane.showInputDialog("Nome:"),
                        JOptionPane.showInputDialog("Telefone:"),
                        JOptionPane.showInputDialog("CPF:"),
                        JOptionPane.showInputDialog("Email:")
                ));
                JOptionPane.showMessageDialog(null, "Contato adicionado.");
            } else if (escolha == 1) {
                Contato contato = agenda.buscarPorNome(JOptionPane.showInputDialog("Nome para busca:"));
                JOptionPane.showMessageDialog(null, contato != null ? contato : "Contato não encontrado.");
            } else if (escolha == 2) {
                String input = JOptionPane.showInputDialog("Índice para busca:");
                if (input.matches("\\d+")) {
                    int indice = Integer.parseInt(input);
                    if (indice >= 0 && indice < agenda.getListaDeContatos().size()) {
                        JOptionPane.showMessageDialog(null, agenda.getListaDeContatos().get(indice));
                    } else {
                        JOptionPane.showMessageDialog(null, "Índice inválido.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Índice inválido.");
                }
            } else if (escolha == 3) {
                boolean excluido = agenda.excluirContato(JOptionPane.showInputDialog("Nome para excluir:"));
                JOptionPane.showMessageDialog(null, excluido ? "Contato excluído." : "Contato não encontrado.");
            } else if (escolha == 4) {
                String nome = JOptionPane.showInputDialog("Nome para editar:");
                Contato contato = agenda.buscarPorNome(nome);
                if (contato != null) {
                    contato.setNome(JOptionPane.showInputDialog("Novo Nome:", contato.getNome()));
                    contato.setTelefone(JOptionPane.showInputDialog("Novo Telefone:", contato.getTelefone()));
                    contato.setCpf(JOptionPane.showInputDialog("Novo CPF:", contato.getCpf()));
                    contato.setEmail(JOptionPane.showInputDialog("Novo Email:", contato.getEmail()));
                    JOptionPane.showMessageDialog(null, "Contato editado.");
                } else {
                    JOptionPane.showMessageDialog(null, "Contato não encontrado.");
                }
            } else if (escolha == 5) {
                String lista = String.join("\n", agenda.getListaDeContatos().toString());
                JOptionPane.showMessageDialog(null, lista.isEmpty() ? "Nenhum contato registrado." : lista);
            } else if (escolha == 6) {
                JOptionPane.showMessageDialog(null, agenda.salvar() ? "Contatos salvos." : "Erro ao salvar.");
                return;
            }
        }
    }
}