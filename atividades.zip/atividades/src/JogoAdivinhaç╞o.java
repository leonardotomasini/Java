import javax.swing.JOptionPane;
import java.util.Random;

public class JogoAdivinhação {
    public static void main(String[] args) {
        Random random = new Random();
        int numeroSecreto = random.nextInt(100) + 1;
        int tentativas = 0;
        int chute = 0;

        JOptionPane.showMessageDialog(null, "Digite um numero entre 1 e 100 para tentar acertar. ");

        while (chute != numeroSecreto) {
            chute = Integer.parseInt(JOptionPane.showInputDialog("Digite :"));
            tentativas++;

            if (chute < numeroSecreto) {
                JOptionPane.showMessageDialog(null, "O numero é menor que o certo. Tente novamente.");
            } else if (chute > numeroSecreto) {
                JOptionPane.showMessageDialog(null, "O numero é maior que o certo. Tente novamente.");
            } else {
                JOptionPane.showMessageDialog(null, "Numero acertado " + numeroSecreto + " em " + tentativas + " tentativas.");
            }
        }
    }
}