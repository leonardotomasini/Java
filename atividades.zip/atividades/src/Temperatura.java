import javax.swing.JOptionPane;

public class Temperatura {
    public static void main(String[] args) {
        double temperatura = Double.parseDouble(JOptionPane.showInputDialog("Digite a temperatura em Fahrenheit: "));
        double conta =  5 * ((temperatura-32) / 9);
        JOptionPane.showMessageDialog(null, "A temperatura é " + conta + " em celcius.");


    }
}
