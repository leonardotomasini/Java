import javax.swing.*;
public class MetroCm {
    public static void main (String [] args) {
        String input = JOptionPane.showInputDialog(null, "Digite a quantida de metros");

        double Metros = Double.parseDouble(input);
        double Centimetros = Metros * 100;
        JOptionPane.showMessageDialog(null, "Esses metros são " + Centimetros + " Centimetros.");


    }
}
