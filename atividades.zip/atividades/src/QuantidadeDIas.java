import javax.swing.*;

public class QuantidadeDIas {
    public static void main (String [] args) {
        String input = JOptionPane.showInputDialog(null, "Digite a quantida de anos");

        double TotalAnos = Integer.parseInt(input);
        double dias = TotalAnos * 365.25;
        JOptionPane.showMessageDialog(null, "Esses anos possuem " + dias + "dias no total");


    }
}
