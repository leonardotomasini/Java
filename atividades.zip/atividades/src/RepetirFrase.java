import javax.swing.*;

public class RepetirFrase {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null,"Escreva a frase: ");
        System.out.println(input);
        System.out.println(input);
        System.out.println(input);

    }
}