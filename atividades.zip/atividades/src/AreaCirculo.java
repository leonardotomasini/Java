import javax.swing.*;

public class AreaCirculo {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null,"digite o raio: ");
        double raio = Integer.parseInt(input);
        double area = Math.PI * raio * raio;
        JOptionPane.showMessageDialog(null, "a área do circulo é " + area);

    }
}