import javax.swing.*;

public class VerificarSenha {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null,"Escreva a senha: ");
        String senha = "batata";
        if (input.equals(senha)) {
            JOptionPane.showMessageDialog(null, "Senha acertada. ");
        } else {
            JOptionPane.showMessageDialog(null,"Senha errada.");
        }

    }
}