import javax.swing.*;

public class NumeroInteiroMultiplo {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null,"Escreva o numero inteiro: ");
        double numero = Integer.parseInt(input);
        if (numero % 3 == 0 && numero % 7 == 0) {
            JOptionPane.showMessageDialog(null, "É multiplo de 3 e 7 ao mesmo tempo. ");
        } else {
            JOptionPane.showMessageDialog(null,"Não é multiplo de 3 e 7 ao mesmo tempo.");
        }

    }
}