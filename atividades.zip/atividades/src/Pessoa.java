import javax.swing.JOptionPane;

public class Pessoa implements Comparable<Pessoa> {
    private String nome;
    private int idade;
    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
    @Override
    public String toString() {
        return "Nome: " + nome + ", Idade: " + idade;
    }
    @Override
    public int compareTo(Pessoa outraPessoa) {
        return Integer.compare(this.idade, outraPessoa.idade);
    }
    public static void main(String[] args) {
        String nome1 = JOptionPane.showInputDialog("nome da primeira pessoa:");
        int idade1 = Integer.parseInt(JOptionPane.showInputDialog("idade da primeira pessoa:"));

        String nome2 = JOptionPane.showInputDialog("nome da segunda pessoa:");
        int idade2 = Integer.parseInt(JOptionPane.showInputDialog("idade da segunda pessoa:"));

        Pessoa pessoa1 = new Pessoa(nome1, idade1);
        Pessoa pessoa2 = new Pessoa(nome2, idade2);

        JOptionPane.showMessageDialog(null, "pessoa 1: " + pessoa1);
        JOptionPane.showMessageDialog(null, "pessoa 2: " + pessoa2);

        int resultado = pessoa1.compareTo(pessoa2);
        if (resultado > 0) {
            JOptionPane.showMessageDialog(null, pessoa1.nome + " é mais velho que " + pessoa2.nome);
        } else if (resultado < 0) {
            JOptionPane.showMessageDialog(null, pessoa2.nome + " é mais velho que " + pessoa1.nome);
        } else {
            JOptionPane.showMessageDialog(null, "ambos têm a mesma idade.");
        }
    }
}