import javax.swing.*;

public class AprovadoReprovado {
    public static void main(String[] args){
        String A = JOptionPane.showInputDialog(null,"Digite a nota 1:");
        String B = JOptionPane.showInputDialog(null,"Digite a nota 2:");
        String C = JOptionPane.showInputDialog(null,"Digite a nota 3:");
        String D = JOptionPane.showInputDialog(null,"Digite a nota 4:");

        double nota1 = Double.parseDouble(A);
        double nota2 = Double.parseDouble(B);
        double nota3 = Double.parseDouble(C);
        double nota4 = Double.parseDouble(D);

        double media = (nota1 +nota2 + nota3 + nota4) /4;

        if (media >= 7) {
            JOptionPane.showMessageDialog(null, "Aluno aprovado!");
        } else if (media < 7 && media >= 5) {
            JOptionPane.showMessageDialog(null, "Aluno em exame");
        } else {
            JOptionPane.showMessageDialog(null, "Aluno reprovado");
        }

    }

}
