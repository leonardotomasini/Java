import javax.swing.JOptionPane;

public class FraseNumeroInteiro {
    public static void main(String[] args) {

        String mensagem = JOptionPane.showInputDialog("Digite a frase:");

        int vezes = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de vezes que quer repetir a frase:"));

        String resultado = "";
        for (int i = 0; i < vezes; i++) {
            resultado += mensagem + "\n";
        }

        JOptionPane.showMessageDialog(null, resultado);
    }
}