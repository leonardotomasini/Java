import javax.swing.JOptionPane;

public class SalarioDespesas {
    public static void main(String[] args) {
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Salário recebido:"));
        double despesas = Double.parseDouble(JOptionPane.showInputDialog("Despesas:"));

        if (despesas <= salario) {
            JOptionPane.showMessageDialog(null, "Gasto dentro do orçamento");
        } else {
            JOptionPane.showMessageDialog(null, "Orçamento estourado");
        }
    }
}