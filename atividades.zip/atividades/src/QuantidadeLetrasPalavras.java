import javax.swing.JOptionPane;

/// teve chat gpt em algumas partes pq não sabia como fazer a contagem em java

public class QuantidadeLetrasPalavras{
    public static void main(String[] args) {
        String frase = JOptionPane.showInputDialog("Digite uma frase: ");

        int Letras = frase.replaceAll("[^a-zA-Z]", "").length();
        int Palavras = frase.trim().split("\\s+").length;

        JOptionPane.showMessageDialog(null, "Quantidade de letras: " + Letras + "\nQuantidade de palavras: " + Palavras);
    }
}