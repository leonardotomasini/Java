import javax.swing.JOptionPane;

public class HorasSalário {
    public static void main(String[] args) {
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Digite quanto você ganha por hora: "));
        double horas = Double.parseDouble(JOptionPane.showInputDialog("Digite quantas horas você trabalha por mês: "));

        double conta = salario * horas;
        JOptionPane.showMessageDialog(null, "você ganha " + conta + " reais por mês");


    }
}