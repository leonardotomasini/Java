import javax.swing.*;

public class FraseLonga {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null,"Escreva a frase: ");
        if (input.length() > 20) {
            JOptionPane.showMessageDialog(null, "A frase é maior que 20 caracteres.");
        } else {
            JOptionPane.showMessageDialog(null, "A frase é menor ou igual a 20 caracteres.");
        }
    }
}