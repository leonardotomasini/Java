import javax.swing.*;

public class AprovadoReprovadoExame {
    public static void main(String[] args){
        String A = JOptionPane.showInputDialog(null,"Digite a nota 1:");
        String B = JOptionPane.showInputDialog(null,"Digite a nota 2:");
        String C = JOptionPane.showInputDialog(null,"Digite a nota 3:");
        String D = JOptionPane.showInputDialog(null,"Digite a nota 4:");

        double nota1 = Double.parseDouble(A);
        double nota2 = Double.parseDouble(B);
        double nota3 = Double.parseDouble(C);
        double nota4 = Double.parseDouble(D);

        double media = (nota1 +nota2 + nota3 + nota4) /4;

        if (media >=7) {
            JOptionPane.showMessageDialog(null,"Aluno aprovado!");
        } else {
            JOptionPane.showMessageDialog(null, "Aluno em exame");
            String exame = JOptionPane.showInputDialog(null,"Digite a nota do exame:");
            double recuperação = Double.parseDouble(exame);
            Double conta = recuperação + media / 2;
            if (conta >= 5) {
                JOptionPane.showMessageDialog(null, "Aluno aprovado");
            }  {
                JOptionPane.showMessageDialog(null, "Aluno reprovado!");
            }


        }

    }

}
