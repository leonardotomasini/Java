import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog(null,"digite o numero: ");
        int numero = Integer.parseInt(input);
        int quadrado = numero * numero;
        JOptionPane.showMessageDialog(null, "o quadrado de " + numero + " é: " + quadrado);

    }
}