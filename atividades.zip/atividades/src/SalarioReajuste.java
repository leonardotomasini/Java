import javax.swing.JOptionPane;

public class SalarioReajuste {
    public static void main(String[] args) {
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Digite o salário:"));
        double reajuste;

        if (salario < 500) {
            reajuste = salario * 1.15;
        } else if (salario <= 1000) {
            reajuste = salario * 1.10;
        } else {
            reajuste = salario * 1.05;
        }
        JOptionPane.showMessageDialog(null, "O novo salário é: R$ " + reajuste);
    }
}
