import javax.swing.JOptionPane;

public class LeituraXY {
    public static void main(String[] args) {

        int x = Integer.parseInt(JOptionPane.showInputDialog("Escreva a quantidade de números divisíveis deseja encontrar :"));

        int y = Integer.parseInt(JOptionPane.showInputDialog("Digite o número divisor :"));

        String resultado = "Os primeiros " + x + " números divisíveis por " + y + " são:\n";
        int contador = 0;
        int numero = 0;

        while (contador < x) {
            if (numero % y == 0) {
                resultado += numero + "\n";
                contador++;
            }
            numero++;
        }

        JOptionPane.showMessageDialog(null, "Os primeiros " + x + " números divisíveis por " + y + " são:\n");
    }
}