public class Main {
    public Main() {
    }

    public static void main(String[] args) {

        Cordenada posicaoInicial = new Cordenada(0, 0);

        Retangulo retangulo = new Retangulo(10, 5, "azul", posicaoInicial);

        System.out.println("retângulo inicial: " + (retangulo));

        System.out.println("area: " + retangulo.getArea());

        System.out.println("perímetro: " + retangulo.getPerimetro());

        retangulo.deslocarEmX(5);

        retangulo.deslocarEmY(10);

        System.out.println("retângulo após deslocamento: " + (retangulo));

        retangulo.escala(2, 3);

        System.out.println("retângulo após escala: " + (retangulo));

        retangulo.rotacao90Graus();

        System.out.println("retângulo após rotação de 90 graus: " + (retangulo));

    }
}
