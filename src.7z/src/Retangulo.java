public class Retangulo {
    private int largura, altura;
    private String cor;
    private Cordenada posicao;

    public Retangulo(int largura, int altura, String cor, Cordenada posicao) {
        this.largura = largura;
        this.altura = altura;
        this.cor = cor;
        this.posicao = posicao;
    }

    public int getLargura() {
        return this.largura;
    }

    public void setLargura(int largura) {
        this.largura = largura;
    }

    public int getAltura() {
        return this.altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public String getCor() {
        return this.cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public Cordenada getPosicao() {
        return this.posicao;
    }

    public void setPosicao(Cordenada posicao) {
        this.posicao = posicao;
    }

    public int getArea() {
        return this.largura * this.altura;
    }

    public int getPerimetro() {
        return 2 * (this.largura + this.altura);
    }

    public void deslocarEmX(int deslocamentox) {
        this.posicao.setX(this.posicao.getX() + deslocamentox);
    }

    public void deslocarEmY(int deslocamentoy) {
        this.posicao.setY(this.posicao.getY() + deslocamentoy);
    }

    public void escala(int fatorX, int fatorY) {
        this.largura *= fatorX;
        this.altura *= fatorY;
    }

    public void rotacao90Graus() {
        int temp = this.largura;
        this.largura = this.altura;
        this.altura = temp;
    }


    @Override
    public String toString() {
        return "Retângulo [largura=" + this.largura + ", altura=" + this.altura + ", cor=" + this.cor
                + ", posição=" + this.posicao + "]";
    }
}