public class Retangulo {
    private int largura, altura;
    private String cor;
    private Cordenada posição;

    public Retangulo(int largura, int altura, String cor, Cordenada posição) {
        this.largura = largura;
        this.altura = altura;
        this.cor = cor;
        this.posição = posição;
    }

    public int getLargura() {
        return largura;
    }

    public void setLargura(int largura) {
        this.largura = largura;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public Cordenada getPosição() {
        return posição;
    }

    public void setPosição(Cordenada posição) {
        this.posição = posição;
    }

    public int getArea() {
        return largura * altura;
    }

    public int getPerimetro() {
        return 2 * (largura + altura);
    }

    public void deslocarEmX(int deslocamentox) {
        posição.setX(posição.getX() + deslocamentox);
    }

    public void deslocarEmY(int deslocamentoy) {
        posição.setY(posição.getY() + deslocamentoy);
    }

    public void escala(int fatorX, int fatorY) {
        largura *= fatorX;
        altura *= fatorY;
    }

    public void rotacao90Graus() {
        int temp = largura;
        largura = altura;
        altura = temp;
    }

    @Override
    public String toString() {
        return "Retangulo{" +
                "largura=" + largura +
                ", altura=" + altura +
                ", cor='" + cor + '\'' +
                ", posição=" + posição +
                '}';
    }
}
