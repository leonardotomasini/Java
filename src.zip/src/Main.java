public class Main {
    public static void main(String[] args) {

        Cordenada cordenada = new Cordenada(5, 10);
        Retangulo retangulo = new Retangulo(10, 20, "Azul turquesa", cordenada);
        System.out.println(retangulo);
        System.out.println("Área: " + retangulo.getArea());
        System.out.println("Perímetro: " + retangulo.getPerimetro());
        retangulo.deslocarEmX(15);
        retangulo.deslocarEmY(33);
        System.out.println("Após deslocamento: " + retangulo);
        retangulo.escala(3, 6);
        System.out.println("Após escalonamento: " + retangulo);
        retangulo.rotacao90Graus();
        System.out.println("Após rotação de 90 graus: " + retangulo);


        Quadrado quadrado = new Quadrado(10, 10, "vermelho", cordenada);
        System.out.println(quadrado);
        System.out.println("Área do quadrado: " + quadrado.getArea());
        System.out.println("Perímetro do quadrado: " + quadrado.getPerimetro());
        quadrado.deslocarEmX(10);
        quadrado.deslocarEmY(15);
        System.out.println("Quadrado após deslocamento: " + quadrado);
        quadrado.escala(2, 2);
        System.out.println("Quadrado após escalonamento: " + quadrado);
    }
}