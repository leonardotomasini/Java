public class Quadrado extends Retangulo {
    public Quadrado(int largura, int altura, String cor, Cordenada posição) {
        super(largura, altura, cor, posição);
    }
    public int getlado(){
        return getLargura();

    }

    public void setlado(int lado){
        setLargura(lado);
        setAltura(lado);
    }

    @Override
    public String toString() {
        return "Quadrado{}" +
                "lado=" + getlado() +
                "Cor=" + getCor() +
                "Posição" + getPosição();
    }
}
